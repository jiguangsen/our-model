from tqdm import tqdm
from scipy import optimize
import tensorflow as tf
from utils import *
import json
import os
import numpy
 
seed = 12306
np.random.seed(seed)
#choose the GPU, "-1" represents using the CPU
os.environ["CUDA_VISIBLE_DEVICES"] = "-1"

ace_file = "C:/code/EA/LSM_test/LSM-main/vec_ae_ja_10000.txt"
ent_path = "C:/code/EA/LSM_test/LSM-main/translated_ent_name/dbp_ja_en.json"
# ent_path = "C:/code/EA/LSM_test/LSM-main/translated_ent_name/dbp_zh_en.json"
# ent_path = "C:/code/EA/LSM_test/LSM-main/translated_ent_name/dbp_fr_en.json"
file_path = "C:/code/EA/LSM_test/LSM-main/KGs/dbp_ja_en/"
# file_path = "C:/code/EA/LSM_test/LSM-main/KGs/dbp_zh_en/"
# file_path = "C:/code/EA/LSM_test/LSM-main/KGs/dbp_fr_en/"
glove_path = "C:/code/EA/LSM_test/LSM-main/glove.6B.300d.txt"

def load_datas(ace_file,ent_path,file_path,glove_path):
    # load 300d
    word_vecs = {}
    with open(glove_path,encoding='UTF-8') as f:
        for line in tqdm(f.readlines()):
            line = line.split()
            word_vecs[line[0]] = np.array([float(x) for x in line[1:]])

    #load the translated entity names 
    all_triples,node_size,rel_size = load_triples(file_path,True)
    train_pair,test_pair,all_pair = load_aligned_pair(file_path,ratio=0.3)

    # build the relational adjacency matrix
    dr = {}
    for x,r,y in all_triples:
        if r not in dr:
            dr[r] = 0
        dr[r] += 1
        
    sparse_rel_matrix = []
    for i in range(node_size):
        sparse_rel_matrix.append([i,i,np.log(len(all_triples)/node_size)]);
    for h,r,t in all_triples:
        sparse_rel_matrix.append([h,t,np.log(len(all_triples)/dr[r])])
    sparse_rel_matrix = np.array(sorted(sparse_rel_matrix,key=lambda x:x[0]))
    sparse_rel_matrix = tf.SparseTensor(indices=sparse_rel_matrix[:,:2],values=sparse_rel_matrix[:,2],dense_shape=(node_size,node_size))

    # generate the bigram dictionary
    ent_names = json.load(open(ent_path,"r"))
    d = {}
    count = 0
    for _,name in ent_names:
        for word in name:
            word = word.lower() 
            for idx in range(len(word)-1):
                if word[idx:idx+2] not in d:
                    d[word[idx:idx+2]] = count
                    count += 1

    # load vec_ae  
    vec_ae = numpy.loadtxt(ace_file)
    return word_vecs,all_triples,node_size,rel_size,train_pair,test_pair,all_pair,sparse_rel_matrix,vec_ae,d,ent_names

def cal_sims_train(train_pair,feature):
    feature_a = tf.gather(indices=train_pair[:,0],params=feature)
    feature_b = tf.gather(indices=train_pair[:,1],params=feature)
    return tf.matmul(feature_a,tf.transpose(feature_b,[1,0]))

def cal_sims_test(test_pair,feature):
    feature_a = tf.gather(indices=test_pair[:,0],params=feature)
    feature_b = tf.gather(indices=test_pair[:,1],params=feature)
    return tf.matmul(feature_a,tf.transpose(feature_b,[1,0]))

def cal_sims_all(all_pair,feature):
    feature_a = tf.gather(indices=all_pair[:,0],params=feature)
    feature_b = tf.gather(indices=all_pair[:,1],params=feature)
    return tf.matmul(feature_a,tf.transpose(feature_b,[1,0]))

def init_parameters():
    flist = np.random.dirichlet(np.ones(3),size=1)[0]
    for num in range(0,len(flist)):
        flist[num] = round(flist[num],2)
    
    wlist = np.random.dirichlet(np.ones(3),size=1)[0]
    for num in range(0,len(wlist)):
        wlist[num] = round(wlist[num],2)

    rnum = 3
    return flist,wlist,rnum

def opt_parameters():
    flist = [0.4,0.5,0.1]    
    wlist = [0.047,0.51,0.43] 
    rnum = 3   
    return flist,wlist,rnum

def train_part(epoch,flist,wlist,rnum,mode):
    for count in range(1,epoch+1):
        # generate the word-level features and char-level features
        ent_vec = np.zeros((node_size,300))
        char_vec = np.zeros((node_size,len(d)))

        for i,name in ent_names:
            k = 0
            for word in name:
                word = word.lower()
                if word in word_vecs:  
                    ent_vec[i] += word_vecs[word]
                    k += 1
                else:
                    results = []  
                    results = [word[i:i + x + 1] for x in range(len(word)) for i in range(len(word) - x)]
                    for kk in range(len(results)):
                        if results[kk] in  word_vecs :
                            if len(results[kk]) > rnum:
                                ent_vec[i] += word_vecs[results[kk]]
                                k += 1    

                for idx in range(len(word)-1):
                    char_vec[i,d[word[idx:idx+2]]] += 1 
            if k:  
                ent_vec[i]/=k
            else: 
                ent_vec[i] = np.random.random(300)-0.5

                
            if np.sum(char_vec[i]) == 0:
                char_vec[i] = np.random.random(len(d))-0.5

            ent_vec[i] = ent_vec[i]/ np.linalg.norm(ent_vec[i])
            char_vec[i] = char_vec[i]/ np.linalg.norm(char_vec[i])

        #feature selection 
        if mode == "word-level":
            feature = ent_vec
        if mode == "char-level":
            feature = char_vec
        if mode == "hybrid-level": 
            feature = np.concatenate([flist[0]*ent_vec,flist[1]*char_vec,flist[2]*vec_ae],-1)
        feature = tf.nn.l2_normalize(feature,axis=-1)

        ent_vec_zeros = np.zeros((node_size,300))
        char_vec_zeros = np.zeros((node_size,len(d)))
        vec_ae_zeros = np.zeros((node_size,100))
        simres = np.concatenate([ent_vec_zeros,char_vec_zeros,vec_ae_zeros],-1)

        # SEU
        simres = cal_sims_train(train_pair,simres)
        for line in range(1,len(wlist)+1):
            featuretmp =  feature
            sims = cal_sims_train(train_pair,featuretmp)
            for i in range(line):    
                featuretmp = tf.sparse.sparse_dense_matmul(sparse_rel_matrix,featuretmp)
                featuretmp = tf.nn.l2_normalize(featuretmp,axis=-1)
                sims += cal_sims_train(train_pair,featuretmp)
            sims /= line+1
            simres += (wlist[line-1]*sims)  

        # optimize parameters
        flist,wlist,rnum = opt_parameters()

        simres = tf.exp(simres*50)
        for k in range(10):
            simres = simres / tf.reduce_sum(simres,axis=1,keepdims=True)
            simres = simres / tf.reduce_sum(simres,axis=0,keepdims=True)
        hits1res,hits10res,mrrres = test(simres,"sinkhorn")
        print("[train_acc %d/%d ] hits@1 : %.2f%% hits@10 : %.2f%% MRR : %.2f%%\n" % (count,epoch,hits1res,hits10res,mrrres))

    return flist,wlist,rnum 

def test_part(flist,wlist,rnum,mode):
    # generate the word-level features and char-level features
    ent_vec = np.zeros((node_size,300))
    char_vec = np.zeros((node_size,len(d)))
    # simres = np.concatenate([ent_vec,char_vec],-1)

    for i,name in ent_names:
        k = 0
        for word in name:
            word = word.lower()
            if word in word_vecs:  
                ent_vec[i] += word_vecs[word]
                k += 1
            else:
                results = []  
                results = [word[i:i + x + 1] for x in range(len(word)) for i in range(len(word) - x)]
                for kk in range(len(results)):
                    if results[kk] in  word_vecs :
                        if len(results[kk]) > rnum:
                            ent_vec[i] += word_vecs[results[kk]]
                            k += 1    

            for idx in range(len(word)-1):
                char_vec[i,d[word[idx:idx+2]]] += 1 
        if k:  
            ent_vec[i]/=k
        else: 
            ent_vec[i] = np.random.random(300)-0.5

            
        if np.sum(char_vec[i]) == 0:
            char_vec[i] = np.random.random(len(d))-0.5

        ent_vec[i] = ent_vec[i]/ np.linalg.norm(ent_vec[i])
        char_vec[i] = char_vec[i]/ np.linalg.norm(char_vec[i])

    #feature selection 
    if mode == "word-level":
        feature = ent_vec
    if mode == "char-level":
        feature = char_vec
    if mode == "hybrid-level": 
        feature = np.concatenate([flist[0]*ent_vec,flist[1]*char_vec,flist[2]*vec_ae],-1)
    feature = tf.nn.l2_normalize(feature,axis=-1)

    ent_vec_zeros = np.zeros((node_size,300))
    char_vec_zeros = np.zeros((node_size,len(d)))
    vec_ae_zeros = np.zeros((node_size,100))
    simres = np.concatenate([ent_vec_zeros,char_vec_zeros,vec_ae_zeros],-1)

    # SEU
    simres = cal_sims_all(train_pair,simres)
    for line in range(1,len(wlist)+1):
        featuretmp =  feature
        sims = cal_sims_all(train_pair,featuretmp)
        for i in range(line):    
            featuretmp = tf.sparse.sparse_dense_matmul(sparse_rel_matrix,featuretmp)
            featuretmp = tf.nn.l2_normalize(featuretmp,axis=-1)
            sims += cal_sims_all(train_pair,featuretmp)
        sims /= line+1
        simres += (wlist[line-1]*sims)  

    return simres

if __name__ == '__main__':
    # load datas
    word_vecs,all_triples,node_size,rel_size,train_pair,test_pair,all_pair,sparse_rel_matrix,vec_ae,d,ent_names = load_datas(ace_file,ent_path,file_path,glove_path)

    # init parameters
    flist,wlist,rnum = init_parameters()

    epoch = 2
    mode = "hybrid-level"

    # train
    flist,wlist,rnum = train_part(epoch,flist,wlist,rnum,mode)

    # test
    simver = test_part(flist,wlist,rnum,mode)

    # get resulut
    simver = tf.exp(simver*50)
    for k in range(10):
        simver = simver / tf.reduce_sum(simver,axis=1,keepdims=True)
        simver = simver / tf.reduce_sum(simver,axis=0,keepdims=True)
    hits1res,hits10res,mrrres = test(simver,"sinkhorn")
    print("[sinkhorn test_acc] hits@1 : %.2f%% hits@10 : %.2f%% MRR : %.2f%%\n" % (hits1res,hits10res,mrrres))

    simver = optimize.linear_sum_assignment(simver,maximize=True)
    i,_,_ = test(simver,"hungarian")
    print("[hungarian test_acc] hits@1 : %.2f%%"%(i))